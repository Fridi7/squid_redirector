from os import system

system("sudo apt-get install squid -y")
system("mkdir /build ")
system("cp redirector.py /build/")
system('cp -rf squid.conf /etc/squid/')
system('cp config.json /build/')
system("chmod -R 777 /build")
system("systemctl restart squid")
system("echo 'All done!'")
